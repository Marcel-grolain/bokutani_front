import React from 'react';

import Index from './components/dashboard/Index';

function App() {
  return (
    <div className="App">
      <Index/>
    </div>
  );
}

export default App;
